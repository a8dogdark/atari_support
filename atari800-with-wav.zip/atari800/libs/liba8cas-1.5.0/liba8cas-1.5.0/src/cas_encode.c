/*
 * Copyright (c) 2010-2015 A8CAS developers (see AUTHORS)
 *
 * This file is part of the A8CAS project which allows to manipulate tape
 * images for Atari 8-bit computers.
 *
 * A8CAS is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * A8CAS is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along
 * with A8CAS; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA.
 */
#include <assert.h>
#include <math.h>
#include <stdint.h>
#include <string.h>

#include "cas_encode.h"

#include "a8cas_file.h"
#include "a8cas.h"
#include "pokey_deserialize.h"

/* Minimum length of a MARK signal to be considered an IRG, in seconds */
#define MIN_IRG_LENGTH_S 0.05

/* ======== Functions that write to file ======== */

static int write_long_irg(CAS_ENCODE_t *encode)
{
	while (encode->irg_ms >= 65535.5) {
		if ((*encode->write_fsk_block_func)(encode->file, (uint16_t)65535, NULL, 0) != 0)
			return 1;
		encode->irg_ms -= 65535.0;
	}

	return 0;
}

static int write_data_block(CAS_ENCODE_t *encode)
{
	if (encode->baudrate_changed) {
		if ((*encode->write_baud_block_func)(encode->file, encode->baudrate) != 0)
			return 1;
		encode->baudrate_changed = 0;
	}
	if (write_long_irg(encode) != 0)
		return 1;
	if ((*encode->write_data_block_func)(encode->file, (uint16_t)nearbyint(encode->irg_ms), encode->block_buffer.data, encode->block_buffer_fill) != 0)
		return 1;

	encode->block_buffer_fill = 0;
	encode->irg_ms = 0.0;

	return (*encode->add_block_offset_func)(encode->file, encode->baudrate);
}

static int write_fsk_block(CAS_ENCODE_t *encode)
{
	uint16_t irg_ms;
	int even_fill = encode->block_buffer_fill != 0 && (encode->block_buffer_fill & 0x1) == 0;
	unsigned int fill;

	if (write_long_irg(encode) != 0)
		return 1;

	irg_ms = (uint16_t)nearbyint(encode->irg_ms);
	if (irg_ms == 0 && encode->block_buffer_fill == 0)
		/* The chunk would be empty (sometimes happens on flush when
		   prev_irg rounds down to 0) - don't write. */
		return 0;

	 /* FSK blocks should always have odd length. EVEN_FILL can happen
	    though during flush. */
	fill = encode->block_buffer_fill - even_fill;
	if ((*encode->write_fsk_block_func)(encode->file, (uint16_t)nearbyint(encode->irg_ms), encode->block_buffer.fsk, fill) != 0)
		return 1;

	encode->block_buffer_fill = 0;
	/* If last FSK length was not written, add it to IRG_MS instead. */
	encode->irg_ms = even_fill ? (double)encode->block_buffer.fsk[fill] / 10.0 : 0.0;

	return (*encode->add_block_offset_func)(encode->file, encode->baudrate);
}

/* ======== */

static int irg_process_byte(CAS_ENCODE_t *encode, uint8_t byte, double baudrate);
static int irg_process_signal(CAS_ENCODE_t *encode, uint8_t value, double length);

static int data_process_bytes(CAS_ENCODE_t *encode, uint8_t const *bytes, unsigned int size, double baudrate)
{
	/* Detect baudrate change. */
	{
		double deviation = 1.0 + encode->baudrate_deviation;
		double old_baudrate = (double)encode->baudrate;

		if (baudrate > old_baudrate * deviation ||
		    old_baudrate > baudrate * deviation) {
			uint16_t new_baud_int;
			if (baudrate >= 65536.0) {
				A8CAS_log(encode->file, "Too high baudrate=%f - probably noise", baudrate);
				baudrate = 65535.0;
			}
			/* Round to int and check if there's still a baudrate change. */
			new_baud_int = (uint16_t)nearbyint(baudrate);
			if (new_baud_int != encode->baudrate) {
				if (encode->block_buffer_fill > 0) {
					if (write_data_block(encode) != 0)
						return 1;
				}
				encode->baudrate = new_baud_int;
				encode->baudrate_changed = 1;
			}
		}
	}

	do {
		unsigned int space_left = CAS_ENCODE_DATA_BUF_SIZE - encode->block_buffer_fill;
		unsigned int to_copy;

		if (space_left == 0) {
			/* Artificially split the DATA block. */
			if (write_data_block(encode) != 0)
				return 1;
			space_left = CAS_ENCODE_DATA_BUF_SIZE;
		}

		to_copy = size > space_left ? space_left : size;
		memcpy(encode->block_buffer.data + encode->block_buffer_fill, bytes, to_copy);

		bytes += to_copy;
		size -= to_copy;
		encode->block_buffer_fill += to_copy;

	} while (size > 0);

	return 0;
}

static int data_process_byte(CAS_ENCODE_t *encode, uint8_t byte, double baudrate)
{
	return data_process_bytes(encode, &byte, 1, baudrate);
}

static int data_process_signal(CAS_ENCODE_t *encode, uint8_t value, double length)
{
	if (encode->block_buffer_fill > 0) {
		if (write_data_block(encode) != 0)
			return 1;
	}
	encode->process_byte_func = &irg_process_byte;
	encode->process_signal_func = &irg_process_signal;
	return irg_process_signal(encode, value, length);
}

static int fsk_process_byte(CAS_ENCODE_t *encode, uint8_t byte, double baudrate)
{
	if (write_fsk_block(encode) != 0)
		return 1;
	encode->process_byte_func = &data_process_byte;
	encode->process_signal_func = &data_process_signal;
	return data_process_byte(encode, byte, baudrate);
}

static int fsk_process_signal(CAS_ENCODE_t *encode, uint8_t value, double length)
{
	if (length >= MIN_IRG_LENGTH_S && value != 0) {
		/* Found an IRG. */
		if (write_fsk_block(encode) != 0)
			return 1;
		encode->process_byte_func = &irg_process_byte;
		encode->process_signal_func = &irg_process_signal;
		return irg_process_signal(encode, value, length);
	}

	if (encode->block_buffer_fill >= CAS_ENCODE_FSK_BUF_SIZE) {
		/* Artificially split the FSK block. */
		if (write_fsk_block(encode) != 0)
			return 1;
		/* Assume that CAS_ENCODE_FSK_BUF_SIZE is an odd number;
		therefore the last value in the FSK block corresponds to
		a SPACE signal. */
		assert(value == (uint8_t) 1);
		encode->process_byte_func = &irg_process_byte;
		encode->process_signal_func = &irg_process_signal;
		return irg_process_signal(encode, value, length);
	}

	/* Convert secs to 1/10's of ms. */
	{
		double length_ms = length * 10000.0;
		while (length_ms > 65535.0) {
			/* Artificially split the FSK block. */
			assert(value == 0);
			encode->block_buffer.fsk[encode->block_buffer_fill ++] = 65535;
			if (write_fsk_block(encode) != 0)
				return 1;
			length_ms -= 65535.0;
		}
		encode->block_buffer.fsk[encode->block_buffer_fill ++] = (uint16_t)nearbyint(length_ms);
	}

	return 0;
}

static int irg_process_byte(CAS_ENCODE_t *encode, uint8_t byte, double baudrate)
{
	encode->process_byte_func = &data_process_byte;
	encode->process_signal_func = &data_process_signal;
	return data_process_byte(encode, byte, baudrate);
}

static int irg_process_signal(CAS_ENCODE_t *encode, uint8_t value, double length)
{
	if (value) {
		encode->irg_ms += length * 1000.0;
		return 0;
	}

	encode->process_byte_func = &fsk_process_byte;
	encode->process_signal_func = &fsk_process_signal;

	return fsk_process_signal(encode, value, length);
}

static int write_from_deserialize(CAS_ENCODE_t *encode, POKEY_DESERIALIZE_datatype type)
{
	while (type != POKEY_DESERIALIZE_NONE) {
		if (type == POKEY_DESERIALIZE_BYTE) {
			uint8_t byte;
			double baudrate;

			type = POKEY_DESERIALIZE_get_byte(&encode->deserialize, &byte, &baudrate);
			if ((*encode->process_byte_func)(encode, byte, baudrate) != 0)
				return 1;
		}
		else { /* type == POKEY_DESERIALIZE_SIGNAL */
			uint8_t value;
			double length;

			type = POKEY_DESERIALIZE_get_signal(&encode->deserialize, &value, &length);
			if ((*encode->process_signal_func)(encode, value, length) != 0)
				return 1;
		}
	}

	return 0;
}

static int flush_deserialize(CAS_ENCODE_t *encode)
{
	POKEY_DESERIALIZE_datatype type;
	type = POKEY_DESERIALIZE_flush(&encode->deserialize);

	return write_from_deserialize(encode, type);
}

static int flush_block_buffer(CAS_ENCODE_t *encode)
{
	if (encode->block_buffer_fill > 0) {
		if (encode->process_byte_func == &data_process_byte) {
			if (write_data_block(encode) != 0)
				return 1;
		} else { /* encode->process_byte_func == &fsk_process_byte */
			assert(encode->process_byte_func == &fsk_process_byte);
			if (write_fsk_block(encode) != 0)
				return 1;
		}
		encode->process_byte_func = &irg_process_byte;
		encode->process_signal_func = &irg_process_signal;
	}
	return 0;
}

int CAS_ENCODE_flush(CAS_ENCODE_t *encode)
{
	if (flush_deserialize(encode) != 0)
		return 1;
	if (flush_block_buffer(encode) != 0)
		return 1;

	if (encode->irg_ms * 1000.0 >= MIN_IRG_LENGTH_S) {
		if (write_fsk_block(encode) != 0)
			return 1;
	}
	encode->irg_ms = 0.0;

	return 0;
}

void CAS_ENCODE_init(CAS_ENCODE_t *encode, A8CAS_FILE *file)
{
	encode->baudrate_deviation = 0.05;
	encode->file = file;
	POKEY_DESERIALIZE_init(&encode->deserialize, file);
}

int CAS_ENCODE_alloc(CAS_ENCODE_t *encode)
{
	return (encode->file->errnum = POKEY_DESERIALIZE_alloc(&encode->deserialize)) != A8CAS_ERR_NONE;
}

void CAS_ENCODE_reset(CAS_ENCODE_t *encode, uint16_t baudrate)
{
	encode->baudrate = baudrate;
	encode->irg_ms = 0.0;
	encode->block_buffer_fill = 0;
	encode->process_byte_func = &irg_process_byte;
	encode->process_signal_func = &irg_process_signal;
	POKEY_DESERIALIZE_reset(&encode->deserialize);
}

void CAS_ENCODE_free(CAS_ENCODE_t *encode)
{
	POKEY_DESERIALIZE_free(&encode->deserialize);
}

int CAS_ENCODE_write(CAS_ENCODE_t *encode, A8CAS_signal const *sig)
{
	POKEY_DESERIALIZE_datatype type = POKEY_DESERIALIZE_put(&encode->deserialize, sig);

	return write_from_deserialize(encode, type);
}

int CAS_ENCODE_write_bytes(CAS_ENCODE_t *encode, unsigned char const *bytes, unsigned int size, unsigned int baudrate)
{
	if (flush_deserialize(encode) != 0)
		return 1;

	assert(size > 0);

	if (encode->process_byte_func != &data_process_byte) {
		if ((*encode->process_byte_func)(encode, bytes[0], (double) baudrate) != 0)
			return 1;
		if (--size == 0)
			return 0;
		++bytes;
	}

	assert(encode->process_byte_func == &data_process_byte);

	return data_process_bytes(encode, bytes, size, (double) baudrate);
}

/* Functions for setting parameters. */
int CAS_ENCODE_set_bit_deviation(CAS_ENCODE_t *encode, double value)
{
	A8CAS_errnum errnum = POKEY_DESERIALIZE_set_bit_deviation(&encode->deserialize, value);
	encode->file->errnum = errnum;
	return errnum != A8CAS_ERR_NONE;
}

int CAS_ENCODE_set_stop_bit_deviation(CAS_ENCODE_t *encode, double value)
{
	A8CAS_errnum errnum = POKEY_DESERIALIZE_set_stop_bit_deviation(&encode->deserialize, value);
	encode->file->errnum = errnum;
	return errnum != A8CAS_ERR_NONE;
}

int CAS_ENCODE_set_bit_middle(CAS_ENCODE_t *encode, double value)
{
	A8CAS_errnum errnum = POKEY_DESERIALIZE_set_bit_middle(&encode->deserialize, value);
	encode->file->errnum = errnum;
	return errnum != A8CAS_ERR_NONE;
}

int CAS_ENCODE_set_block_header_length(CAS_ENCODE_t *encode, unsigned int value)
{
	A8CAS_errnum errnum = POKEY_DESERIALIZE_set_block_header_length(&encode->deserialize, value);
	encode->file->errnum = errnum;
	return errnum != A8CAS_ERR_NONE;
}

int CAS_ENCODE_set_block_header_deviation(CAS_ENCODE_t *encode, double value)
{
	A8CAS_errnum errnum = POKEY_DESERIALIZE_set_block_header_deviation(&encode->deserialize, value);
	encode->file->errnum = errnum;
	return errnum != A8CAS_ERR_NONE;
}

int CAS_ENCODE_set_baudrate_deviation(CAS_ENCODE_t *encode, unsigned int value)
{
	if (value < 0.0) {
		encode->file->errnum = A8CAS_ERR_INVALID;
		return 1;
	}
	encode->baudrate_deviation = value;
	return 0;
}
