/*
 * Copyright (c) 2015 A8CAS developers (see AUTHORS)
 *
 * This file is part of the A8CAS project which allows to manipulate tape
 * images for Atari 8-bit computers.
 *
 * A8CAS is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * A8CAS is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along
 * with A8CAS; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA.
 */
#ifndef POKEY_SERIALIZE_H
#define POKEY_SERIALIZE_H

#include <stdint.h>

#include "a8cas.h"

typedef struct POKEY_SERIALIZE_t POKEY_SERIALIZE_t;

struct POKEY_SERIALIZE_t {
	/* Should be set by user. */
	uint16_t baudrate;

	/* Internal variables. */
	uint16_t bit_mask;
	uint16_t current_10bit;
};

/* Puts a new byte BYTE into the serialzier SERIALIZE. */
void POKEY_SERIALIZE_put(POKEY_SERIALIZE_t *serialize, uint8_t byte);

/* Retrieves the next signal from the serializer SERIALIZE and puts it into
   SIG.
   Returns non-zero on end of byte - user should call POKEY_SERIALIZE_put
   before calling POKEY_SERIALIZE_get again. */
int POKEY_SERIALIZE_get(POKEY_SERIALIZE_t *serialize, A8CAS_signal *sig);

#endif /* POKEY_SERIALIZE_H */
