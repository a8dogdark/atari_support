AtrUtil Version 1.13
Last Updated December 5,1998
Copyright 1998 Ken Siders
See AtrUtil.txt (text file) for more information


---Ken



